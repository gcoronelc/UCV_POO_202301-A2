//APELLIDOS: ANACLETO HUERTA
//NOMBRES: RENZO DANIEL

//EXAMEN PARCIAL II

package appuniversidad;

import appuniversidad.view.UniversidadView;

public class AppUniversidad {

    public static void main(String[] args) {
        UniversidadView.main(args);
    }
    
}
